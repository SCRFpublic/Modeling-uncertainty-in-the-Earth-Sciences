function Quantiles = Quantiles_Calculation(FlowResponse,p)


%% function calculating the quantiles of the response, for each time,
%% at probability given by p

% Input Parameters:
%   - Matrix of response, of size Number of realization x Number of
%   timesteps
%  - p is a vector indicating which quantiles to compute

% Output:
% - Vector of Quantiles

Quantiles=zeros(size(FlowResponse,2),length(p));
for i = 1:size(FlowResponse,2)
    Quantiles(i,:)=quantile(FlowResponse(:,i),p);
end

end
