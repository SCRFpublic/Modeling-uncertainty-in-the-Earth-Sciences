

function plot_MDS_response_value(Y,response)

% Function that plots the value of the response as a color assigned to the
% bullet plotted in the MDS map

% Input Parameters:
%    - Y: Location of the points in the MDS map
%    - response:  Value of the response for each point at ONE time step.



Rmax_ = max(response);
Rmin_ = min(response);
Rmax = Rmax_ + 0.02 * (Rmax_ - Rmin_) + 0.0001;
Rmin = Rmin_ - 0.02 * (Rmax_ - Rmin_) - 0.0001;

Cs = [1 0 0;1 1 0;0 1 0;0 1 1;0 0 1];

Rs = linspace(Rmin,Rmax,size(Cs,1));
C = interp1(Rs', Cs, response, 'linear');

figure
for i=1:size(Y,1)
    plot(Y(i,1), Y(i,2), 'o', 'Color',C(i,:), ...
        'MarkerSize', 6,'LineWidth',1,'MarkerFaceColor',C(i,:),...
        'MarkerEdgeColor','k');
    hold on
end
grid on;
set(gca,'LineWidth',3)
set(gca,'XTickLabel',{''})
set(gca,'YTickLabel',{''})


end
