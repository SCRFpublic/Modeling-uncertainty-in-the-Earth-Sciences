function st_sens_inter = Sensitivity_Analysis_Classical(real_params_val,Response,param_names,inter)

%% This function do a classical sensitivity analysis and return a Pareto
%% plot.  The red line represent the value for which a parameter become
%% influent.

%% Author: Celine Scheidt

% real_params_val: property values of the models (preferably defined by ED). Should be normalized between -1 and 1
% Response: vector of reponse of interest at one particular time
% param_names: names of the parameters in the ED
% inter: if inter is ignored - no interractions are employed. Otherwise,
%        all interations between parameters are considered.
 

[nb_real,nb_param] = size(real_params_val);
X_sens_inter = ones(nb_real,1);
X_sens_inter =  horzcat(X_sens_inter,real_params_val);
param_names_inter = param_names;
if nargin  == 4
     
     for i = 1:nb_param-1
         for j = i+1:nb_param
      X_sens_inter = horzcat(X_sens_inter,real_params_val(:,i).*real_params_val(:,j));
      param_names_inter = [param_names_inter,strcat(param_names{i},':',param_names{j})];
         end
     end
end


 C_sens_inter = (transpose(X_sens_inter)*X_sens_inter)^(-1);
 Beta_sens_inter = C_sens_inter*transpose(X_sens_inter)*Response;
 Y_est_sens_inter = X_sens_inter*Beta_sens_inter;

 variance_sens_inter = 0;

 for i = 1:nb_real
     variance_sens_inter = variance_sens_inter + (Response(i)-Y_est_sens_inter(i))^2;
 end

 variance_sens_inter = variance_sens_inter/nb_real;

 st_sens_inter = zeros(1,size(X_sens_inter,2));
 for i = 1:size(X_sens_inter,2)
     st_sens_inter(1,i) = Beta_sens_inter(i)/sqrt((C_sens_inter(i,i)*variance_sens_inter));
 end
 
 
 [valsort,idxsort] = sort(abs(st_sens_inter(2:end)));
 idxsort = idxsort +1;
 figure
 h = axes('FontSize',13);
 barh(abs(st_sens_inter(idxsort)))
 title('Sensitivity of parameters on Response','FontSize',15)
 set(gca,'YTickLabel',param_names_inter(idxsort-1))

 

end
