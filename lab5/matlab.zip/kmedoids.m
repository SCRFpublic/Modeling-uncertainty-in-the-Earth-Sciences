%% Function performing kernel k-medoid clustering

% Author: Celine Scheidt  02/21/2010

% Input Parameters:
% - d: distance matrix(n x n), n being the number of models
% - nbclusters: Number of clusters to construct
% - maxIterations: Maximum number of iterations possibles for the clustering 

% Output Parameters:
% - Clustering.idxtosimulate: indices of the medoids selected by the clustering algorithm.  Length of vector is nbclusters.
% - Clustering.T: vector of lenght n (number of realizations), which indicates to which cluster the realization belongs to.
% - Y: Location of the models in MDS


nbclusters = 5;
maxIterations = 50;

% Multi-Dimensional Scaling (MDS) using distance d
[Y_, e_] = cmdscale(d);

% Dimension of the MDS space
dims = 1;
while sum(e_(1:dims))/sum(e_) < 0.99
    dims = dims + 1;
end
Y = Y_(:,1:dims);

% Plot of the location of realizations in MDS
plotcmdmap_KKM(Y)

% Definition of the kernel matrix - rbf Gaussian
%sigma = 0.2*max(max(d));  % bandwith of the kernel
%K = rbf_kernel(Y,sigma);
K = rbf_kernel(Y);

%% 1. Random selection of the inital nbclusters medoids.
npoints = size(Y,1);
k = randperm(npoints);
k = k(1:nbclusters);

% Compute distance (in the Feature Space defined by the kernel) between each point and the medoids
dist_points_medoids = zeros(npoints,nbclusters);

for i = 1:npoints
    for j = 1:nbclusters
        dist_points_medoids(i,j) = K(i,i) - 2*K(i,k(j)) + K(k(j),k(j));
    end
end
        
%% 2. Associate each points to the closest medoid

[B,T] = min(dist_points_medoids,[],2);

%% 3.  Update the medoid of each cluster and re-assign each point to a cluster

k_new_prev = ones(1,nbclusters);
k_new = zeros(1,nbclusters);
nbIter = 0;

while (~all(k_new == k_new_prev) && nbIter < maxIterations)  % while cluster configuration is changing and maxIteration not reached
    k_new_prev = k_new;
    for i = 1:nbclusters
        idx_in_clusters = find(T == i);
        dist_within_cluster = zeros(size(idx_in_clusters,2),size(idx_in_clusters,2));
        for j = 1:size(idx_in_clusters,1)
                for k = 1:size(idx_in_clusters,1)
                    dist_within_cluster(j,k) = K(idx_in_clusters(j),idx_in_clusters(j)) - 2*K(idx_in_clusters(j),idx_in_clusters(k)) + K(idx_in_clusters(k),idx_in_clusters(k));
                end
        end
        [dclust idx_min] = min(mean(dist_within_cluster));
        k_new(i) = idx_in_clusters(idx_min);
    end

    % New medoids are defined, compute distance between points and medoids
    for i = 1:npoints
        for j = 1:nbclusters
            dist_points_medoids(i,j) = K(i,i) - 2*K(i,k_new(j)) + K(k_new(j),k_new(j));
        end
    end
        
    %% 2. Associate each points to the closest medoid

    [B,T] = min(dist_points_medoids,[],2);
    
    nbIter = nbIter +1;    
        
end
 
Clustering.T = T;  
Clustering.idxtosimulate = k_new;  

% Plot of the clusters in MDS
plotcmdmap_KKM(Y, Clustering)