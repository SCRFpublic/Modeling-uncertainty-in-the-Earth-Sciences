import sgems
def sgems_execute_group_action(gridName,groupName):

  pnames = sgems.get_properties_in_group(gridName,groupName)
  for p in pnames :
    command = "SaveHistogram grid::"+p+"::HIsto "+p+".png"
    sgems.execute(command)
