import sgems

def sgems_execute_group_action(gridName,groupName):
  pnames = sgems.get_properties_in_group(gridName,groupName)
  nan = sgems.nan()
  for pname in pnames :
    data = sgems.get_property(gridName, pname)
    for i in range(len(data)) : 
      if data[i] == nan : data[i] = 0
    sgems.set_property(gridName, pname,data)
