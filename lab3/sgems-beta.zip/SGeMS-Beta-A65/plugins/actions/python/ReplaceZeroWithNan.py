import sgems

def sgems_execute_action(gridName,propName):
  nan = sgems.nan()
  data = sgems.get_property(gridName, propName[0])
  for i in range(len(data)) : 
    if data[i] == 0 : data[i] = nan
  sgems.set_property(gridName, propName[0]+" nan",data)