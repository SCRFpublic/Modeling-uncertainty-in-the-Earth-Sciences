import sgems

def sgems_execute_action(gridName,propName):
  reference = sgems.get_property("walker lake","U")
  data = sgems.get_property(gridName,propName[0])
  errors = [d-r for d,r in zip(data,reference)]
  sgems.set_property(gridName,propName[0]+" errors with reference",errors)
