import sgems

def sgems_execute_action(gridName,propName):
  print gridName, propName
  nan = sgems.nan()
  data = sgems.get_property(gridName, propName[0])
  for i in range(len(data)) : 
    if data[i] == nan : data[i] = 0
  sgems.set_property(gridName, propName[0],data)
